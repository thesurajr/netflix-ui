import React, { useState } from 'react';
import PaymentService from '../services/PaymentService'; // Import your payment service API

const PaymentForm = () => {
  const [amount, setAmount] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [loading, setLoading] = useState(false);
  const [paymentResult, setPaymentResult] = useState(null);

  const handlePayment = async () => {
    setLoading(true);
    try {
      // Call your payment service API
      const response = await PaymentService.processPayment({
        amount,
        cardNumber,
        expiryDate,
        cvv,
      });
      setPaymentResult(response.data); // Assuming the API returns data about the payment result
    } catch (error) {
      console.error('Error processing payment:', error);
      setPaymentResult(null);
    }
    setLoading(false);
  };

  return (
    <div>
      <h2>Payment Form</h2>
      <label>
        Amount:
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
      </label>
      <br />
      <label>
        Card Number:
        <input
          type="text"
          value={cardNumber}
          onChange={(e) => setCardNumber(e.target.value)}
        />
      </label>
      <br />
      <label>
        Expiry Date:
        <input
          type="text"
          value={expiryDate}
          onChange={(e) => setExpiryDate(e.target.value)}
        />
      </label>
      <br />
      <label>
        CVV:
        <input
          type="text"
          value={cvv}
          onChange={(e) => setCvv(e.target.value)}
        />
      </label>
      <br />
      <button onClick={handlePayment} disabled={loading}>
        {loading ? 'Processing...' : 'Pay Now'}
      </button>
      {paymentResult && (
        <div>
          <h3>Payment Result</h3>
          <p>Status: {paymentResult.status}</p>
          <p>Message: {paymentResult.message}</p>
        </div>
      )}
    </div>
  );
};

export default PaymentForm;
