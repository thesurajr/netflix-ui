export const API_KEY = "af0155d58d34da49978ce17d6ff188d7";
export const TMDB_BASE_URL = "https://api.themoviedb.org/3";
